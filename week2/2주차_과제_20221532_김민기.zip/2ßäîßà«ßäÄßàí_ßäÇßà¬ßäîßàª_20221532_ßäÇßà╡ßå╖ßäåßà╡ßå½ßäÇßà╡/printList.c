#include "Header.h"

void printList(int list[]) {
    for(int i = 0; i<10; i++) {
        printf("%d ", list[i]);         //list값 하나씩 출력
    }
    printf("\n");                       //개행
}