#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>

void count(int N, int list[]);
void cleanList(int list[]);
void printList(int list[]);

