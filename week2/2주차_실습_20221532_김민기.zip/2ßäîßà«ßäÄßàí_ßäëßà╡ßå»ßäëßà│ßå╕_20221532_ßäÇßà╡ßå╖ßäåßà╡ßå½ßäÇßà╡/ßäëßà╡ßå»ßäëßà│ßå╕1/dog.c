#include <stdio.h>

void hidog() {
    printf("Hi I'm dog\n");
}