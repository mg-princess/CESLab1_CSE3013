#include <stdio.h>

void hiblackcow();
void hidog();
void hiturtle();

int main() {
    hiblackcow();
    hidog();
    hiturtle();
    return 0;
}