#include <stdio.h>

void hiturtle() {
    printf("Hi I'm turtle\n");
}