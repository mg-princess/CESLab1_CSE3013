#include <stdio.h>

void hiblackcow() {
    printf("Hi I'm blackcow\n");
}