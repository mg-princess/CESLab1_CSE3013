# include <stdio.h>
int main (void) {
    int i;
    double num;
    for (i=0; 1<5; i++) {
        num= (double)i/2 + i;
        printf("num is %f in", num);
    }
    return 0;
}